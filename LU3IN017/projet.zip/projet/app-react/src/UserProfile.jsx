import React, { useState } from "react";
import AddMessage from "./AddMessage.jsx";

function UserProfile({ user, currentUser, addMessage }) {
  const isCurrentUser = user.uid === currentUser.uid;
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");

  const handlePasswordChange = async (e) => {
    e.preventDefault();

    if (newPassword !== confirmPassword) {
        setMessage("Les nouveaux mots de passe ne correspondent pas.");
        return;
    }

    try {
        const response = await fetch("http://localhost:4000/api/user/change-password", {
            method: "POST",
            credentials: 'include', // Important pour les cookies de session
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                currentPassword,
                newPassword,
            }),
        });

        const data = await response.json();

        if (response.ok) {
            setMessage("Mot de passe changé avec succès.");
            setCurrentPassword("");
            setNewPassword("");
            setConfirmPassword("");
        } else {
            setMessage(data.message || "Erreur lors du changement de mot de passe.");
        }
    } catch (error) {
        console.error("Error:", error);
        setMessage("Erreur de connexion au serveur.");
    }
  };

  return (
    <div className="box">
      <h2>Informations du profil</h2>
      <p><strong>Nom d'utilisateur :</strong> {user.uname}</p>
      <p><strong>Nom complet :</strong> {user.fname} {user.lname}</p>
      <p><strong>ID utilisateur :</strong> {user.uid}</p>
      <p><strong>Statut :</strong> {user.admin ? "Administrateur" : "Utilisateur standard"}</p>
      <p><strong>Inscrit :</strong> {user.registered ? "Oui" : "Non"}</p>

      {isCurrentUser && (
        <>
          <hr />
          <h2>Modifier le mot de passe</h2>
          <form onSubmit={handlePasswordChange}>
            <div>
              <label>Mot de passe actuel :</label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
              />
            </div>
            <div>
              <label>Nouveau mot de passe :</label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
            </div>
            <div>
              <label>Confirmer le nouveau mot de passe :</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
            <button type="submit" className="btn">Changer le mot de passe</button>
          </form>
          {message && <p>{message}</p>}

          <hr />
          <h2>Nouveau message</h2>
          <AddMessage addMessage={addMessage} />
        </>
      )}
    </div>
  );
}

export default UserProfile;
